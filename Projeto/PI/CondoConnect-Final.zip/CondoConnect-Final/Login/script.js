const formulario = document.querySelector("form");
const Iemail = document.querySelector(".email");
const Ipassword = document.querySelector(".password");


function login() {
    fetch('http://localhost:8080/users/login', {
        headers: {
            'Accept': 'application/json', 
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({
            email: Iemail.value,
            password: Ipassword.value
        })
    })
    .then(function(res) {console.log(res)})
    .catch(function(res) {console.log(res)})
}
function limpar(){
    Iemail.value = "";
    Ipassword.value = "";
}

formulario.addEventListener("submit", function(event) {
    event.preventDefault();
    login();
    limpar();

});