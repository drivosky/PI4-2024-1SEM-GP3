const formulario = document.querySelector("form");
const Iname = document.querySelector(".name");
const Iemail = document.querySelector(".email");
const Icondominio = document.querySelector(".condominio");
const Ipassword = document.querySelector(".password");


function cadastrar() {
    fetch('http://localhost:8080/users', {
        headers: {
            'Accept': 'application/json', 
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({
            name: Iname.value,
            email: Iemail.value,
            condominio: Icondominio.value,
            password: Ipassword.value
        })
    })
    .then(function(res) {console.log(res)})
    .catch(function(res) {console.log(res)})
}

function limpar(){
    Iname.value = "";
    Iemail.value = "";
    Icondominio.value = "";
    Ipassword.value = "";
}

formulario.addEventListener("submit", function(event) {
    event.preventDefault();
    cadastrar();
    limpar();
    setTimeout(() => {
        alert("Usuário cadastrado com sucesso! Faça o login na aplicação!");
    }, 2000);

});





