document.addEventListener("DOMContentLoaded", function() {
  var popup = document.getElementById("janela-pop-up");
  popup.style.display = "none"; // Garante que o pop-up está fechado quando a página é carregada
});

function togglePopup() {
  var popup = document.getElementById("janela-pop-up");
  if (popup.style.display === "none" || popup.style.display === "") {
    popup.style.display = "block";
  } else {
    popup.style.display = "none";
  }
}

function salvarPerfil() {
  // Save the profile data to a server or local storage
  console.log("Perfil salvo");
}

function ativarInputArquivo() {
  document.getElementById("input-arquivo").click();
}

function atualizarFotoPerfil() {
  var inputFile = document.getElementById("input-arquivo");
  var fotoPerfil = document.querySelector(".foto-perfil");
  fotoPerfil.src = URL.createObjectURL(inputFile.files[0]);
}

function atualizarSenha(event) {
  // Save the new password to a server or local storage
  console.log("Senha atualizada para: " + event.target.value);
}

function atualizarEmail(event) {
  // Save the new email to a server or local storage
  console.log("Email atualizado para: " + event.target.value);
}

function atualizarNumero(event) {
  // Save the new phone number to a server or local storage
  console.log("Número de telefone atualizado para: " + event.target.value);
}