function togglePopup() {
    var popup = document.getElementById("popup");
    if (popup.style.display === "none" || popup.style.display === "") {
        popup.style.display = "block";
    } else {
        popup.style.display = "none";
    }
}

function enviarEmail() {
    var sugestao = document.getElementById("sugestao").value;
    var email = "condconnect01@gmail.com";
    var assunto = "Sugestão de Melhoria";
    var corpoEmail = "Sugestão: " + sugestao;
    
    var mailtoLink = "mailto:" + email + "?subject=" + assunto + "&body=" + corpoEmail;
    
    window.location.href = mailtoLink;
  }



