//---------Menu---------
document.addEventListener("DOMContentLoaded", function () {
    var popup = document.getElementById("popup");
    popup.style.display = "none"; // Garante que o pop-up está fechado quando a página é carregada
});

function togglePopup() {
    var popup = document.getElementById("popup");
    if (popup.style.display === "none" || popup.style.display === "") {
        popup.style.display = "block";
    } else {
        popup.style.display = "none";
    }
}

//---------Galeria de fotos---------
// Select all filter buttons and filterable cards
document.addEventListener("DOMContentLoaded", function () {
    const selectBtn = document.querySelector(".select-btn");
    const listItems = document.querySelector(".list-items");

    selectBtn.addEventListener("click", () => {
        selectBtn.classList.toggle("open");
    });

    const filterableCards = document.querySelectorAll(".filterable_cards .card");

    // Função para filtrar as cartas com base nos itens selecionados
    const filterCards = () => {
        // Obtém os itens marcados, incluindo "Show all"
        const checkedItems = document.querySelectorAll(".list-items .item.checked");
        const selectedNames = Array.from(checkedItems).map(item => item.dataset.name);

        // Itera sobre cada carta filtrável
        filterableCards.forEach(card => {
            // Adiciona a classe "hide" para esconder a carta inicialmente
            card.classList.add("hide");
            // Verifica se a carta corresponde aos itens selecionados ou se "Todos" está selecionado
            if (selectedNames.includes(card.dataset.name) || selectedNames.includes("tudo")) {
                card.classList.remove("hide");
            }
        });
    };

    // Adiciona um ouvinte de evento de clique a cada item da lista de itens
    const items = document.querySelectorAll(".list-items .item");
    items.forEach(item => {
        item.addEventListener("click", () => {
            // Se o item clicado for "Tudo", desmarca todos os outros itens
            if (item.dataset.name === "tudo") {
                items.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove("checked");
                    }
                });
            } else {
                // Se o item clicado não for "Tudo", desmarca "Tudo"
                const showAllCheckbox = document.querySelector(".list-items .item[data-name='tudo']");
                showAllCheckbox.classList.remove("checked");
            }
            // Atualiza a marcação do item clicado
            item.classList.toggle("checked");

            // Verifica se todos os outros itens, exceto "Tudo", estão marcados
            const allOtherItemsChecked = Array.from(items).slice(0, -1).every(otherItem => {
                return otherItem.classList.contains("checked");
            });

            // Se todos os outros itens estiverem marcados, exceto "Tudo", marque "Tudo" e desmarque os outros itens
            if (allOtherItemsChecked) {
                const showAllCheckbox = document.querySelector(".list-items .item[data-name='tudo']");
                showAllCheckbox.classList.add("checked");
                items.forEach(otherItem => {
                    if (otherItem !== showAllCheckbox) {
                        otherItem.classList.remove("checked");
                    }
                });
            }

            // Atualiza a visualização dos cartões filtráveis ao clicar em um item
            filterCards();

            // Atualiza o texto do botão de seleção
            const checked = document.querySelectorAll(".checked");
            const btnText = document.querySelector(".btn-text");
            if (checked.length > 0 && !showAllCheckbox.classList.contains("checked")) {
                btnText.innerText = `${checked.length} Itens Selecionados`;
            } else {
                btnText.innerText = "Todos Selecionados";
            }
        });
    });

    // Marca o checkbox "Tudo" por padrão e exibe todos os itens correspondentes
    const showAllCheckbox = document.querySelector(".list-items .item[data-name='tudo']");
    showAllCheckbox.classList.add("checked");
    filterCards();
});


//---------Card Slider---------
const initSlider = () => {
    const imageList = document.querySelector(".slider-wrapper .image-list");
    const slideButtons = document.querySelectorAll(".slider-wrapper .slide-button");
    const sliderScrollbar = document.querySelector(".container .slider-scrollbar");
    const scrollbarThumb = sliderScrollbar.querySelector(".scrollbar-thumb");
    const maxScrollLeft = imageList.scrollWidth - imageList.clientWidth;

    // Handle scrollbar thumb drag
    scrollbarThumb.addEventListener("mousedown", (e) => {
        const startX = e.clientX;
        const thumbPosition = scrollbarThumb.offsetLeft;
        const maxThumbPosition = sliderScrollbar.getBoundingClientRect().width - scrollbarThumb.offsetWidth;

        // Update thumb position on mouse move
        const handleMouseMove = (e) => {
            const deltaX = e.clientX - startX;
            const newThumbPosition = thumbPosition + deltaX;
            // Ensure the scrollbar thumb stays within bounds
            const boundedPosition = Math.max(0, Math.min(maxThumbPosition, newThumbPosition));
            const scrollPosition = (boundedPosition / maxThumbPosition) * maxScrollLeft;

            scrollbarThumb.style.left = `${boundedPosition}px`;
            imageList.scrollLeft = scrollPosition;
        }
        // Remove event listeners on mouse up
        const handleMouseUp = () => {
            document.removeEventListener("mousemove", handleMouseMove);
            document.removeEventListener("mouseup", handleMouseUp);
        }
        // Add event listeners for drag interaction
        document.addEventListener("mousemove", handleMouseMove);
        document.addEventListener("mouseup", handleMouseUp);
    });
    // Slide images according to the slide button clicks
    slideButtons.forEach(button => {
        button.addEventListener("click", () => {
            const direction = button.id === "prev-slide" ? -1 : 1;
            const scrollAmount = imageList.clientWidth * direction;
            imageList.scrollBy({ left: scrollAmount, behavior: "smooth" });
        });
    });
    // Show or hide slide buttons based on scroll position
    const handleSlideButtons = () => {
        slideButtons[0].style.display = imageList.scrollLeft <= 0 ? "none" : "flex";
        slideButtons[1].style.display = imageList.scrollLeft >= maxScrollLeft ? "none" : "flex";
    }
    // Update scrollbar thumb position based on image scroll
    const updateScrollThumbPosition = () => {
        const scrollPosition = imageList.scrollLeft;
        const thumbPosition = (scrollPosition / maxScrollLeft) * (sliderScrollbar.clientWidth - scrollbarThumb.offsetWidth);
        scrollbarThumb.style.left = `${thumbPosition}px`;
    }
    // Call these two functions when image list scrolls
    imageList.addEventListener("scroll", () => {
        updateScrollThumbPosition();
        handleSlideButtons();
    });
}
window.addEventListener("resize", initSlider);
window.addEventListener("load", initSlider);