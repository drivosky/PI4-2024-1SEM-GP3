USE engenharia_16;

CREATE TABLE usuarios (
    usuario INT PRIMARY KEY AUTO_INCREMENT,
    usuarioNome VARCHAR(100) NOT NULL,
    usuarioEmail VARCHAR(100) NOT NULL UNIQUE,
    usuarioSenha VARCHAR(255) NOT NULL,
    usuarioCpf VARCHAR(14) NOT NULL UNIQUE
);

INSERT INTO usuarios (usuarioNome, usuarioEmail, usuarioSenha, usuarioCpf) VALUES
('Ana Luiza da Costa Franchi', 'ana.franchi@esenac.com', 'admin123', '123.456.789-01'),
('Gabriela Ferrari Sobral', 'gabriela.ferrari@senac.com', 'admin123', '123.456.789-02'),
('Joshua Dias Bento de Fonseca', 'joshua.dias@senac.com', 'admin123', '123.456.789-03'),
('Gabriel Henrique de Avelar Vicente', 'gabriel.henrique@senac.com', 'admin123', '123.456.789-04'),
('Brian Rocumback', 'brian.rocumback@senac.com', 'admin123', '123.456.789-05');